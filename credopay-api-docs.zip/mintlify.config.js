export default {
  name: "CredoPay API Docs",
  sidebar: "_sidebar.mdx",
  logo: "/logo.png",
  basePath: "/docs",
};